package com.demo.indy;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DeliverCallback;
import com.rabbitmq.client.Delivery;
import com.rabbitmq.client.*;

import java.io.*;
import java.util.ArrayList;
import java.util.*;
import java.util.Scanner;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import java.util.concurrent.TimeUnit;

public class App {

	 private final static String QUEUE_NAME = "IndyProject";
	static long SentTime;

	@SuppressWarnings({ "deprecation" })
	public static void main(String[] argv) throws Exception {
		
		String Queue_name;
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost("149.165.171.155");
		//factory.setHost("localhost");
		factory.setUsername("iarora");
		factory.setPassword("iarora");
		Connection connection = factory.newConnection();
		Channel channel = connection.createChannel();
		
		channel.queueDeclare(QUEUE_NAME, true, false, false, null);
		
		File file = new File("C:\\Users\\ishne\\OneDrive\\Documents\\INDY CAR\\IPBroadcaster_Input_2018-05-27_0.log");
		BufferedReader br = new BufferedReader(new FileReader(file));
		
		String[] arrOfStr;
		String str;
		
		while ((str = br.readLine()) != null) {
		
			arrOfStr = str.split("\\�");
			String message = str;
			
			//channel.basicPublish("", QUEUE_NAME, null, message.getBytes("UTF-8"));
			channel.basicPublish("",QUEUE_NAME,MessageProperties.PERSISTENT_TEXT_PLAIN,message.getBytes("UTF-8"));
			
			/*
			try {
				if (str.startsWith("$P")) {
					Queue_name = "Car_" + arrOfStr[1];
					// System.out.println(str);

					 message = str;
					channel.queueDeclare(Queue_name, false, false, false, null);
					channel.basicPublish("", Queue_name, null, message.getBytes("UTF-8"));
					//System.out.println(" [x] Sent '" + message + "'");
				}
				else if (str.startsWith("$C")) {
					Queue_name = "CompletedLaps";
					 message = str;
					channel.queueDeclare(Queue_name, false, false, false, null);
					channel.basicPublish("", Queue_name, null, message.getBytes("UTF-8"));
				//	System.out.println(" [x] Sent '" + message + "'");
				}
				else if (str.startsWith("$S")) {
					Queue_name = "CompletedSection";
					 message = str;
					channel.queueDeclare(Queue_name, false, false, false, null);
					channel.basicPublish("", Queue_name, null, message.getBytes("UTF-8"));
					//System.out.println(" [x] Sent '" + message + "'");
				}
				else if (str.startsWith("$T")) {
					Queue_name = "TrackInfo";
					 message = str;
					channel.queueDeclare(Queue_name, false, false, false, null);
					channel.basicPublish("", Queue_name, null, message.getBytes("UTF-8"));
					//System.out.println(" [x] Sent '" + message + "'");
				}
				else if (str.startsWith("$O")) {
					Queue_name = "OverallResults";
					 message = str;
					channel.queueDeclare(Queue_name, false, false, false, null);
					channel.basicPublish("", Queue_name, null, message.getBytes("UTF-8"));
					//System.out.println(" [x] Sent '" + message + "'");
				}
				else if (str.startsWith("$R")) {
					Queue_name = "RunInfo";
					 message = str;
					channel.queueDeclare(Queue_name, false, false, false, null);
					channel.basicPublish("", Queue_name, null, message.getBytes("UTF-8"));
					//System.out.println(" [x] Sent '" + message + "'");
				}
				else if (str.startsWith("$F")) {
					Queue_name = "FlagInfo";
					 message = str;
					channel.queueDeclare(Queue_name, false, false, false, null);
					channel.basicPublish("", Queue_name, null, message.getBytes("UTF-8"));
					//System.out.println(" [x] Sent '" + message + "'");
				}
				else if (str.startsWith("$E")) {
					Queue_name = "EntryInfo";
					 message = str;
					channel.queueDeclare(Queue_name, false, false, false, null);
					channel.basicPublish("", Queue_name, null, message.getBytes("UTF-8"));
					//System.out.println(" [x] Sent '" + message + "'");
				}
			}

			catch (Exception e) {
				// System.out.println(e);
			}
	*/
		}

	}
}
