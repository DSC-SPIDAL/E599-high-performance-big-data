package com.demo.indy;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DeliverCallback;
import com.rabbitmq.client.Delivery;
import com.rabbitmq.client.*;

import java.io.*;
import java.util.*;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import java.util.concurrent.TimeUnit;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.DistinctIterable;
import org.bson.Document;
import org.bson.conversions.Bson;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.model.Indexes;
import com.mongodb.internal.connection.Time;
import com.mongodb.client.model.IndexOptions;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.IndexOptions;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.stream.Collectors;

import static com.mongodb.client.model.Aggregates.*;
import com.mongodb.Block;
import com.mongodb.DB;

public class App_BKP {

	private final static String QUEUE_NAME = "IndyProject";

	// @SuppressWarnings({ "deprecation" })
	public static void main(String[] argv) throws Exception {

		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost("149.165.171.155");
		factory.setUsername("iarora");
		factory.setPassword("iarora");
		Connection connection = factory.newConnection();

		Channel channel = connection.createChannel();
		channel.queueDeclare(QUEUE_NAME, true, false, false, null);

		Timer timer = new Timer();
		// channel.basicQos(1000);
		ArrayList<String> messages = new ArrayList<String>();

		DeliverCallback deliverCallback = (consumerTag, delivery) -> {

			String message = new String(delivery.getBody(), "UTF-8");

			// System.out.println(" [x] Received '" + message + "'");
			
			try {

				// 

				messages.add(message);
				
				if (messages.size() == 1000) {
					System.out.println("Message Count is 1000, going to insert");
					System.out.println(messages.size());
					 //writeDb(messages);
					messages.removeAll(messages);
				}
				
				if (messages.size() !=0) {
					
				}
				
				}
			catch (Exception e) {
				System.out.println(e);
			} finally {
				channel.basicAck(delivery.getEnvelope().getDeliveryTag(), false);
			}
		};

		if (messages.size() > 0)
			writeDb(messages);
		channel.basicConsume(QUEUE_NAME, false, deliverCallback, consumerTag -> {
		});
	}

	private static void writeDb(ArrayList<String> messages) {// System.out.println("Inside writeDb");
																// System.out.println("Hello");

		//MongoClient mongo = new MongoClient("149.165.168.117", 27017);
		
		MongoClient mongo = new MongoClient(
			    new MongoClientURI("mongodb://149.165.170.196:27017,149.165.168.117:27017"));
		
		MongoDatabase database = mongo.getDatabase("test_final");
		System.out.println("Connected to the database successfully");

		// List<ServerAddress> lstServer = new ArrayList<ServerAddress>();
		// lstServer.add(new ServerAddress("149.165.170.196", 27017));
		// lstServer.add(new ServerAddress("149.165.168.117", 27017));

		// MongoClient mongoclient = new MongoClient(lstServer);
		/*
		 * MongoClient mongoClient = new MongoClient( new MongoClientURI(
		 * "mongodb://149.165.170.196:27017,149.165.168.117:27017/?replicaSet=rs0"));
		 */
		// System.out.println("Connected to the database successfully");

		// MongoDatabase database = mongo.getDatabase("HPBDS");
		// DB database = mongoclient.getDB("HPBDS");
		// System.out.println("Connected to the database successfully");
		// System.out.println("Created successDocument");

		MongoCollection<Document> Telemetry_$P = database.getCollection("telemetry");
		MongoCollection<Document> CompletedLaps_$C = database.getCollection("CompletedLaps");
		MongoCollection<Document> CompletedSection_$S = database.getCollection("CompletedSection");
		MongoCollection<Document> TrackInfo_$T = database.getCollection("TrackInfo");
		MongoCollection<Document> OverallResults_$O = database.getCollection("OverallResults");
		MongoCollection<Document> RunInfo_$R = database.getCollection("RunInfo");
		MongoCollection<Document> FlagInfo_$F = database.getCollection("FlagInfo");
		MongoCollection<Document> EntryInfo_$E = database.getCollection("EntryInfo");

		List<Document> docs_Telemetry = new ArrayList<>();
		List<Document> docs_CompletedLaps = new ArrayList<>();
		List<Document> docs_CompletedSection = new ArrayList<>();
		List<Document> docs_Trackinfo = new ArrayList<>();
		List<Document> docs_OverallResults = new ArrayList<>();
		List<Document> docs_RunInfo = new ArrayList<>();
		List<Document> docs_FlagInfo = new ArrayList<>();
		List<Document> docs_EntryInfo = new ArrayList<>();

		int counter_$S = 0;
		int counter_$O = 0;
		String flag_from_$h = "not yet initialized";
		int hours;
		int minutes;
		double seconds;
		// for $C gets activated when $R event round is not equal to "Sweeps"
		String event_name = "not yet initialized";
		String run_command = "not yet initialized";
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
		LocalDate localDate = LocalDate.now();
		// System.out.println(dtf.format(localDate));
		String race_id = dtf.format(localDate);

		while (messages.size() > 0) {
			String line = messages.remove(0);

			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Date date = new Date();

			if (line.startsWith("$P")) {
				String[] splits = line.split("�");
				String command = splits[0];
				String carNumber = splits[1];
				String timeOfDay = splits[2];
				String[] time_array = timeOfDay.split(":");
				String lapDistance = splits[3];
				String vehicleSpeed = splits[4];
				String engineSpeed = splits[5];
				String throttle = splits[6];
				String RaceID = String.valueOf(race_id);

				Document document = new Document();

				document.append("command", command);
				document.append("car_num", carNumber);
				document.append("lap_distance", lapDistance);
				document.append("time_of_day", timeOfDay);

				if (run_command.equals("R") && (!flag_from_$h.contentEquals("U")) && (!flag_from_$h.contentEquals("C"))
						&& (!flag_from_$h.contentEquals("not yet initialized")) && timeOfDay.length() >= 11) {
					// System.out.println(Arrays.toString(splits));
					hours = Integer.parseInt(time_array[0]);
					minutes = Integer.parseInt(time_array[1]);
					seconds = Double.parseDouble(time_array[2]);
					document.append("hours", hours);
					document.append("minutes", minutes);
					document.append("seconds", seconds);
					document.append("time_for_comparison", 1);

				} else if (timeOfDay.length() >= 11) {
					hours = Integer.parseInt(time_array[0]);
					minutes = Integer.parseInt(time_array[1]);
					seconds = Double.parseDouble(time_array[2]);
					document.append("hours", hours);
					document.append("minutes", minutes);
					document.append("seconds", seconds);

					document.append("time_for_comparison", 0);
				} else {
					document.append("time_for_comparison", 0);
				}

				document.append("vehicle_speed", vehicleSpeed);
				document.append("engine_rpm", engineSpeed);
				document.append("throttle", throttle);
				document.append("date", date);
				document.append("race_id", RaceID);
				document.append("flag_from_$h", flag_from_$h);
				document.append("run_command", run_command);
				// document.append("counter_overall_results", counter_$O);

				if (docs_Telemetry.size() == 100) {
					Telemetry_$P.insertMany(docs_Telemetry);
					docs_Telemetry.clear();
				} else {
					docs_Telemetry.add(document);
				}
			}

			else if (line.startsWith("$C")) {

				// completed laps, start position, overall position will be integers

				// Time behind prec 15, Laps behind prec 16, Overall best lap time 18 not
				// included along with 1,2,3,4 positioned items in record
				String[] splits = line.split("�");
				String command = splits[0];
				// String rank=splits[4];
				String carNumber = splits[5];
				String completed_laps = splits[7];
				String elapsed_time = splits[8];
				String last_laptime = splits[9];
				String lap_status = splits[10];
				String best_lap_time = splits[11];
				String best_lap = splits[12];
				String times_behind_leader = splits[13];
				String laps_behind_leader = splits[14];
				String overall_rank = splits[17];
				String current_status = splits[19];
				String track_status = splits[20];
				String pit_stop_counts = splits[21];
				String last_pitted_lap = splits[22];
				String start_position = splits[23];
				String laps_led = splits[24];
				String RaceID = String.valueOf(race_id);

				//

				Document document = new Document();
				document.append("command", command);
				// document.append("rank", Integer.parseInt(rank,16));
				document.append("car_num", carNumber);
				document.append("completed_laps", Integer.parseInt(completed_laps, 16));
				document.append("elapsed_time", elapsed_time);
				document.append("last_laptime", last_laptime);
				document.append("lap_status", lap_status);
				document.append("best_lap_time", best_lap_time);
				document.append("best_lap", best_lap);
				document.append("times_behind_leader", times_behind_leader);
				document.append("laps_behind_leader", laps_behind_leader);
				document.append("overall_rank", Integer.parseInt(overall_rank, 16));
				document.append("current_status", current_status);
				document.append("track_status", track_status);
				document.append("pit_stop_counts", pit_stop_counts);
				document.append("last_pitted_lap", Integer.parseInt(last_pitted_lap, 16));
				document.append("start_position", Integer.parseInt(start_position, 16));
				document.append("laps_led", laps_led);
				document.append("event_name", event_name);
				document.append("run_command", run_command);
				document.append("race_id", RaceID);

				if (docs_CompletedLaps.size() == 100) {
					CompletedLaps_$C.insertMany(docs_CompletedLaps);
					docs_CompletedLaps.clear();
				} else {
					docs_CompletedLaps.add(document);
				}
			}

			else if (line.startsWith("$S")) {

				// last lap is integer.

				String[] splits = line.split("�");
				String command = splits[0];
				String carNumber = splits[4];
				String section_identifier = splits[6];
				String elapsed_time = splits[7];
				String last_section_time = splits[8];
				String last_lap = splits[9];

				String RaceID = String.valueOf(race_id);

				Document document = new Document();
				document.append("command", command);
				document.append("car_num", carNumber);
				document.append("section_identifier", section_identifier);
				document.append("elapsed_time", elapsed_time);
				document.append("last_section_time", last_section_time);
				document.append("last_lap", Integer.parseInt(last_lap, 16));
				document.append("event_name", event_name);
				document.append("run_command", run_command);
				document.append("race_id", RaceID);
				document.append("unrelated_counter", counter_$S);
				counter_$S = counter_$S + 1;

				if (docs_CompletedSection.size() == 100) {
					CompletedSection_$S.insertMany(docs_CompletedSection);
					docs_CompletedSection.clear();
				} else {
					docs_CompletedSection.add(document);
				}
			}

			else if (line.startsWith("$T")) { // Track records facing issue, because I am inserting multiple track
												// records for the same race.
				String[] splits = line.split("�");
				String command = splits[0];
				String track_name = splits[4];
				String venue = splits[5];
				String track_length = splits[6];
				String number_of_sections = splits[7];
				String RaceID = String.valueOf(race_id);

				List<Document> embed_document = new ArrayList<Document>();

				// ---
				Document document = new Document();
				document.append("command", command);
				document.append("track_name", track_name);
				document.append("venue", venue);
				document.append("track_length", track_length);
				document.append("number_of_sections", number_of_sections);

				document.append("race_id", RaceID);
				// --

				for (int m = 8; m < splits.length; m = m + 4) {
					Document sub_doc = new Document();
					sub_doc.append("section_name", splits[m]);
					sub_doc.append("section_length", splits[m + 1]);
					sub_doc.append("section_start", splits[m + 2]);
					sub_doc.append("section_end", splits[m + 3]);
					embed_document.add(sub_doc);
				}
				document.append("section_information", embed_document);

				if (docs_Trackinfo.size() == 100) {
					TrackInfo_$T.insertMany(docs_Trackinfo);
					docs_Trackinfo.clear();
				} else {
					docs_Trackinfo.add(document);
				}
			} else if (line.startsWith("$O")) {

				String[] splits = line.split("�");
				String command = splits[0]; // 1,2,3,4 are type,sequence,preamble,resultID are missing
				String Deleted = splits[5];
				String Marker = splits[6];
				String Rank = splits[7];
				String overall_rank = splits[8];
				String start_position = splits[9];
				String best_lap_time = splits[10];
				String best_lap = splits[11];
				String last_lap_time = splits[12];
				String laps = splits[13];
				String total_time = splits[14];
				String last_warm_up_qual_time = splits[15];
				String lap1_QualTime = splits[16];
				String lap2_QualTime = splits[17];
				String lap3_QualTime = splits[18];
				String lap4_QualTime = splits[19];
				String total_QualTime = splits[20];
				String status = splits[21];
				String diff = splits[22];
				String gap = splits[23];
				String on_track = splits[24];
				String pit_stops = splits[25];
				String last_pit_lap = splits[26];
				String since_pit_lap = splits[27];
				String flag_status = splits[28];
				String no = splits[29];
				String first_name = splits[30];
				String last_name = splits[31];
				String Class = splits[32];
				String equipment = splits[33];
				String license = splits[34];
				String team = splits[35];
				String total_entrant_points = splits[36];
				String total_driver_points = splits[37];
				String comment = splits[38];
				String total_chasis_points = splits[39];
				String total_engine_points = splits[40];
				String off_track = splits[41];
				String non_tow_rank = splits[42];
				String non_tow_lap = splits[43];
				String non_tow_time = splits[44];
				String on_track_passes = splits[45];
				String on_track_times_passed = splits[46];
				String overtake_remaining = splits[47];
				String tire_type = splits[48];
				String driver_id = splits[49];
				String qualifying_speed = splits[50];
				String RaceID = String.valueOf(race_id);

				// ---
				Document document = new Document();
				document.append("command", command);
				document.append("Deleted", Deleted);
				document.append("Marker", Marker);
				document.append("Rank", Integer.parseInt(Rank, 16));
				document.append("overall_rank", Integer.parseInt(overall_rank, 16));
				document.append("start_position", start_position);
				document.append("best_lap_time", best_lap_time);
				document.append("best_lap", best_lap);
				document.append("last_lap_time", last_lap_time);
				document.append("laps", laps);
				document.append("total_time", total_time);
				document.append("last_warm_up_qual_time", last_warm_up_qual_time);
				document.append("lap1_QualTime", lap1_QualTime);
				document.append("lap2_QualTime", lap2_QualTime);
				document.append("lap3_QualTime", lap3_QualTime);
				document.append("lap4_QualTime", lap4_QualTime);
				document.append("total_QualTime", total_QualTime);
				document.append("status", status);
				document.append("diff", diff);
				document.append("gap", gap);
				document.append("on_track", on_track);
				document.append("pit_stops", pit_stops);
				document.append("last_pit_lap", last_pit_lap);
				document.append("since_pit_lap", since_pit_lap);
				document.append("flag_status", flag_status);
				document.append("no", no);
				document.append("first_name", first_name);
				document.append("last_name", last_name);
				document.append("Class", Class);
				document.append("equipment", equipment);
				document.append("license", license);
				document.append("team", team);
				document.append("total_entrant_points", total_entrant_points);
				document.append("total_driver_points", total_driver_points);
				document.append("comment", comment);
				document.append("total_chasis_points", total_chasis_points);
				document.append("total_engine_points", total_engine_points);
				document.append("off_track", off_track);
				document.append("non_tow_rank", non_tow_rank);
				document.append("non_tow_lap", non_tow_lap);
				document.append("non_tow_time", non_tow_time);
				document.append("on_track_passes", on_track_passes);
				document.append("on_track_times_passed", on_track_times_passed);
				document.append("overtake_remaining", overtake_remaining);
				document.append("tire_type", tire_type);
				document.append("driver_id", driver_id);
				document.append("qualifying_speed", qualifying_speed);
				document.append("race_id", RaceID);
				// counter_$O=counter_$O+1;
				// document.append("counter_overall_results", counter_$O);

				// --

				if (docs_OverallResults.size() == 100) {
					OverallResults_$O.insertMany(docs_OverallResults);
					docs_OverallResults.clear();
				} else {
					docs_OverallResults.add(document);
				}
			}

			else if (line.startsWith("$R")) {
				String[] splits = line.split("�");
				String command = splits[0];
				event_name = splits[4];
				String event_round = splits[5];
				String run_name = splits[6];
				run_command = splits[7];
				String start_time_date = splits[8];
				String RaceID = String.valueOf(race_id);

				Document document = new Document();
				document.append("command", command);
				document.append("event_name", event_name);
				document.append("event_round", event_round);
				document.append("run_name", run_name);
				document.append("run_command", run_command);
				document.append("start_time_date", start_time_date);
				document.append("race_id", RaceID);
				if (docs_RunInfo.size() == 100) {
					RunInfo_$R.insertMany(docs_RunInfo);
					docs_RunInfo.clear();
				} else {
					docs_RunInfo.add(document);
				}
			} else if (line.startsWith("$F")) {
				String[] splits = line.split("�");
				String command = splits[0];
				String track_status = splits[4];
				String lap_number = splits[5];
				String green_time = splits[6];
				String green_laps = splits[7];
				String yellow_time = splits[8];
				String yellow_laps = splits[9];
				String red_time = splits[10];
				String number_of_yellows = splits[11];
				String current_leader = splits[12];
				String number_of_lead_changes = splits[13];
				String average_race_speed = splits[14];
				String RaceID = String.valueOf(race_id);

				Document document = new Document();
				document.append("command", command);
				document.append("track_status", track_status);
				document.append("lap_number", lap_number);
				document.append("green_time", green_time);
				document.append("green_laps", green_laps);
				document.append("yellow_time", yellow_time);
				document.append("yellow_laps", yellow_laps);
				document.append("red_time", red_time);
				document.append("number_of_yellows", number_of_yellows);
				document.append("current_leader", current_leader);
				document.append("number_of_lead_changes", number_of_lead_changes);
				document.append("average_race_speed", average_race_speed);
				document.append("race_id", RaceID);

				if (docs_FlagInfo.size() == 100) {
					FlagInfo_$F.insertMany(docs_FlagInfo);
					docs_FlagInfo.clear();
				} else {
					docs_FlagInfo.add(document);
				}
			}

			else if (line.startsWith("$E")) {
				String[] splits = line.split("�");
				String command = splits[0];
				String car_number = splits[4];
				String unique_identifier = splits[5];
				String driver_name = splits[6];
				String start_position = splits[7];
				String field_count = splits[8];
				String Class = splits[9];
				String driver_id = splits[10];
				String transponder_control = splits[11];
				String equipment = splits[12];
				String license = splits[13];
				String team = splits[14];
				String team_id = splits[15];
				String engine = splits[16];
				String entrant_id = splits[17];
				String points_eligible = splits[19]; // documentation given is wrong, confirm.
				String hometown = splits[18];
				String competitor_id = splits[20];

				String RaceID = String.valueOf(race_id);

				Document document = new Document();
				document.append("command", command);
				document.append("car_number", car_number);
				document.append("unique_identifier", unique_identifier);
				document.append("driver_name", driver_name);
				document.append("start_position", start_position);
				document.append("field_count", field_count);
				document.append("Class", Class);
				document.append("driver_id", driver_id);
				document.append("transponder_control", transponder_control);
				document.append("equipment", equipment);
				document.append("license", license);
				document.append("team", team);
				document.append("team_id", team_id);
				document.append("engine", engine);
				document.append("entrant_id", entrant_id);
				document.append("points_eligible", points_eligible);
				document.append("hometown", hometown);
				document.append("competitor_id", competitor_id);

				document.append("race_id", RaceID);

				if (docs_EntryInfo.size() == 100) {
					try {
						EntryInfo_$E.insertMany(docs_EntryInfo);
					} catch (Exception e) {
						System.out.println(e);
					}
					docs_EntryInfo.clear();
				} else {
					docs_EntryInfo.add(document);
				}
			}

			else if (line.startsWith("$H")) {
				// System.out.println(line);
				String[] splits = line.split("�");
				flag_from_$h = splits[4];
			}

		}

		if (docs_Telemetry.size() > 0)
			Telemetry_$P.insertMany(docs_Telemetry);
		if (docs_CompletedLaps.size() > 0)
			CompletedLaps_$C.insertMany(docs_CompletedLaps);
		if (docs_CompletedSection.size() > 0)
			CompletedSection_$S.insertMany(docs_CompletedSection);
		if (docs_Trackinfo.size() > 0)
			TrackInfo_$T.insertMany(docs_Trackinfo);
		if (docs_OverallResults.size() > 0)
			OverallResults_$O.insertMany(docs_OverallResults);
		if (docs_RunInfo.size() > 0)
			RunInfo_$R.insertMany(docs_RunInfo);
		if (docs_FlagInfo.size() > 0)
			FlagInfo_$F.insertMany(docs_FlagInfo);
		if (docs_EntryInfo.size() > 0)
			EntryInfo_$E.insertMany(docs_EntryInfo);
	}

}
