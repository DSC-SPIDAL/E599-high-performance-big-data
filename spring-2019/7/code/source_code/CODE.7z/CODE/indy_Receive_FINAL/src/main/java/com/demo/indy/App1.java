package com.demo.indy;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DeliverCallback;
import com.rabbitmq.client.Delivery;
import com.rabbitmq.client.*;

import java.io.*;
import java.util.ArrayList;
import java.util.*;
import java.util.Scanner;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import java.util.concurrent.TimeUnit;

public class App1 {

	 private final static String QUEUE_NAME = "IndyProject";
	static long SentTime;

	@SuppressWarnings({ "deprecation" })
	public static void main(String[] argv) throws Exception {
		ArrayList<Integer> list = new ArrayList<Integer>();
		String carcount = argv[0];
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost("149.165.171.155");
		// factory.setHost("j-016");
		 factory.setUsername("iarora");
		 factory.setPassword("iarora");
		Connection connection = factory.newConnection();
		Channel channel = connection.createChannel();
		// channel.queueDeclare(QUEUE_NAME, false, false, false, null);

		// Consumer
		Connection conn = factory.newConnection();
		Channel channel2 = connection.createChannel();
		// channel2.queueDeclare(QUEUE_NAME, false, false, false, null);

		ArrayList<Integer> cars = new ArrayList<Integer>();
		File file = new File("C:\\Users\\ishne\\OneDrive\\Documents\\INDY CAR\\IPBroadcaster_Input_2018-05-27_0.log");
		BufferedReader br = new BufferedReader(new FileReader(file));
		String[] arrOfStr;
		String carNumber;
		String timeOfDay;
		String lapDistance;
		String vehicleSpeed;
		String engineSpeed;
		String throttle;
		String Queue_name;
		String str;
		int number = 0;
		while ((str = br.readLine()) != null) {
			number = number + 1;
			arrOfStr = str.split("\\�");
			String message = str;
			channel.queueDeclare(QUEUE_NAME, false, false, false, null);
			channel.basicPublish("", QUEUE_NAME, null, message.getBytes("UTF-8"));
			try {
				if (str.startsWith("$P")) {
					Queue_name = "Car_" + arrOfStr[1];
					// System.out.println(str);

					 message = str;
					channel.queueDeclare(Queue_name, false, false, false, null);
					channel.basicPublish("", Queue_name, null, message.getBytes("UTF-8"));
					//System.out.println(" [x] Sent '" + message + "'");
				}
				else if (str.startsWith("$C")) {
					Queue_name = "CompletedLaps";
					 message = str;
					channel.queueDeclare(Queue_name, false, false, false, null);
					channel.basicPublish("", Queue_name, null, message.getBytes("UTF-8"));
				//	System.out.println(" [x] Sent '" + message + "'");
				}
				else if (str.startsWith("$S")) {
					Queue_name = "CompletedSection";
					 message = str;
					channel.queueDeclare(Queue_name, false, false, false, null);
					channel.basicPublish("", Queue_name, null, message.getBytes("UTF-8"));
					//System.out.println(" [x] Sent '" + message + "'");
				}
				else if (str.startsWith("$T")) {
					Queue_name = "TrackInfo";
					 message = str;
					channel.queueDeclare(Queue_name, false, false, false, null);
					channel.basicPublish("", Queue_name, null, message.getBytes("UTF-8"));
					//System.out.println(" [x] Sent '" + message + "'");
				}
				else if (str.startsWith("$O")) {
					Queue_name = "OverallResults";
					 message = str;
					channel.queueDeclare(Queue_name, false, false, false, null);
					channel.basicPublish("", Queue_name, null, message.getBytes("UTF-8"));
					//System.out.println(" [x] Sent '" + message + "'");
				}
				else if (str.startsWith("$R")) {
					Queue_name = "RunInfo";
					 message = str;
					channel.queueDeclare(Queue_name, false, false, false, null);
					channel.basicPublish("", Queue_name, null, message.getBytes("UTF-8"));
					//System.out.println(" [x] Sent '" + message + "'");
				}
				else if (str.startsWith("$F")) {
					Queue_name = "FlagInfo";
					 message = str;
					channel.queueDeclare(Queue_name, false, false, false, null);
					channel.basicPublish("", Queue_name, null, message.getBytes("UTF-8"));
					//System.out.println(" [x] Sent '" + message + "'");
				}
				else if (str.startsWith("$E")) {
					Queue_name = "EntryInfo";
					 message = str;
					channel.queueDeclare(Queue_name, false, false, false, null);
					channel.basicPublish("", Queue_name, null, message.getBytes("UTF-8"));
					//System.out.println(" [x] Sent '" + message + "'");
				}
			}

			catch (Exception e) {
				// System.out.println(e);
			}

		}

	}
}
