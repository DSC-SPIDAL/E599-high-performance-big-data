package com.demo.indy;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DeliverCallback;
import com.rabbitmq.client.Delivery;
import com.rabbitmq.client.*;


import java.io.*;
import java.util.ArrayList;
import java.util.*;
import java.util.Scanner;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import java.util.concurrent.TimeUnit;

public class App2 {

	private final static String QUEUE_NAME = "Latency";
	static long SentTime;

	@SuppressWarnings({ "deprecation" })
	public static void main(String[] argv) throws Exception {
		ArrayList<Integer> list = new ArrayList<Integer> ();
		String carcount = argv[0];
		
		
		

	    
		//Sender
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost("localhost");
		//factory.setHost("j-016");
		//factory.setUsername("iarora");
        //factory.setPassword("iarora");
		Connection connection = factory.newConnection();
		Channel channel = connection.createChannel();
		channel.queueDeclare(QUEUE_NAME, false, false, false, null);
		
		//Consumer
		Connection conn = factory.newConnection();
		Channel channel2 = connection.createChannel();
		channel2.queueDeclare(QUEUE_NAME, false, false, false, null);
		
		
		System.out.println(carcount);
		
		if (Integer.parseInt(carcount) == 1)
		{
			list.addAll(Arrays.asList(22));
		}
		else if (Integer.parseInt(carcount) == 8) {
			list.addAll(Arrays.asList(22,88,66,23,24,25,26,27));
			
	          }
		
		else if (Integer.parseInt(carcount) == 33) {
			list.addAll(Arrays.asList(22,88,66,23,24,25,26,27,28,29,98,32,12,14,59,15,17,18,19,1,3,4,6,7,60,64,20,21,30,10,33,13));
		}
		
		else {
			System.out.println("Car number can be 1,8,33 only as of now");
		System.exit(0);
		}
		
		//System.exit(0);
		System.out.println("Testing for number of cars:" +carcount );
		System.out.println("List of cars" + Arrays.toString(list.toArray()));

		File file = new File("C:\\Users\\ishne\\OneDrive\\Documents\\INDY CAR\\IPBroadcaster_Input_2018-05-27_0.log");
		//File file = new File("/N/u/iarora/PROJECT/IPBroadcaster_Input_2018-05-27_0.log");
		BufferedReader br=new BufferedReader(new FileReader(file));
		// File file = new File("/N/u/iarora/PROJECT/scripts/dum.txt");
		//Scanner sc = new Scanner(file);
		List<Long> latencies = new ArrayList<>();
		//String str;
		String[] arrOfStr;
		String carNumber;
		String timeOfDay;
		String lapDistance;
		String vehicleSpeed;
		String engineSpeed;
		String throttle;

		int count = 1;
		System.out.println(count);
		//System.out.println(sc.hasNext());
		FileWriter file2 = new FileWriter("C:\\\\Users\\\\ishne\\\\OneDrive\\\\Documents\\\\INDY CAR\\\\car_results.txt", true);
		String str;
		int number=0;
		while ((str=br.readLine())!=null) {
			number=number+1;
			//System.out.println(number);
			//str = sc.nextLine();
			arrOfStr = str.split("\\�");
			try {

				carNumber = arrOfStr[1];
				timeOfDay = arrOfStr[2];
				lapDistance = (arrOfStr[3]);
				vehicleSpeed = (arrOfStr[4]);
				engineSpeed = (arrOfStr[5]);
				throttle = (arrOfStr[6]);
				if (str.startsWith("$P")) {
					if ((!timeOfDay.matches("\\d+:\\d+:\\d+.\\d+")) || carNumber == "N"
							|| (Integer.parseInt(carNumber) > 101)) {
						//System.out.println("ERROR Not matching to right date format or the Car Number");
						// is greater than 30");
					} else {
						//System.out.println(number+" Gattu  " +str);
						//System.out.println(carNumber+" "+count);
						if (count == 20001) {
							break;
						}

						if (list.contains(Integer.parseInt(carNumber)))
						{
							TimeUnit.MICROSECONDS.sleep(1);
							//System.out.println("right");
							String message = carNumber+" : "+count;
							System.out.println(message);
							
							SentTime = (long) System.nanoTime();
							channel.basicPublish("", QUEUE_NAME, null, message.getBytes("UTF-8"));
							System.out.println(" [x] Sent '" + message + "'");
							
							
							

								/*DeliverCallback deliverCallback = (a, delivery) -> {
								String message1 = new String(delivery.getBody(), "UTF-8");
								long RecvTime = System.nanoTime();
								System.out.println(" [x] Received '" + message1 + "'");
								long Result = RecvTime - SentTime;
								// System.out.println(Result);
								file2.append(String.valueOf(Result));
								file2.append("\n\r");
								// latencies.add(Result);

							};
							channel.basicConsume(QUEUE_NAME, true, deliverCallback, consumerTag -> {
							});
							*/
							//channel.basicGet(QUEUE_NAME, true);
							GetResponse response = channel.basicGet(QUEUE_NAME, false);
							if(response != null) {
								long RecvTime = System.nanoTime();
								long Result = RecvTime - SentTime;
								file2.append(String.valueOf(Result));
								file2.append("\n\r");
								long deliveryTag = response.getEnvelope().getDeliveryTag();
								message = new String(response.getBody(), "UTF-8");
								System.out.println(" [x] Received '" + message + "'");
								}
							count += 1;
						}

					}
				}

			} catch (Exception e) {
				//System.out.println(e);
			}

		}
	}
}
